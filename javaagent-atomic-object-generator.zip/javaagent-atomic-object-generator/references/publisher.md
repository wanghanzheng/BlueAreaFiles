# Event publisher Java file

Use this reference when generating `javaagent/csp-mml/src/main/java/com.huawei.uda.mml/publisher/<AtomicObject>EventPublisher.java`.

## Fixed source template

Replace only `<AtomicObject>`:

```java
package com.huawei.uda.mml.publisher;

import com.huawei.cloududn.utility.commons.spring.ApplicationContextHolder;
import com.huawei.uda.base.event.AbstractEventPublisher;
import com.huawei.uda.base.event.BaseEvent;

public class <AtomicObject>EventPublisher extends AbstractEventPublisher {
    private static final <AtomicObject>EventPublisher INSTANCE = new <AtomicObject>EventPublisher();

    public static <AtomicObject>EventPublisher getINSTANCE() {
        return INSTANCE;
    }

    @Override
    public void publish(BaseEvent event) {
        if (!preCheck(event)) {
            return;
        }
        ApplicationContextHolder.getApplicationContext().publishEvent(event);
    }
}
```

Write the file under the `publisher` directory. Do not add object-specific fields, event imports, or other behavior.
