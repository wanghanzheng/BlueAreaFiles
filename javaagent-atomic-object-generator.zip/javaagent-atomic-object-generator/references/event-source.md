# Shared EventSource declaration

Every generated Event class references an EventSource constant. Update the shared declaration file after generating `<AtomicObject>Event.java`.

## Target file

Modify exactly:

```text
javaagent/service-base/src/main/java/com.huawei.uda.base/event/EventSource.java
```

## Declaration to add

Derive the uppercase snake-case token from the atomic-object name, then ensure this declaration exists:

```text
<TOKEN>_MANAGER
```

Examples:

- `AcBindArea` → `AC_BIND_AREA_MANAGER`
- `UdaAreaRange` → `UDA_AREA_RANGE_MANAGER`

This must match the reference used in the generated Event class:

```java
EventSource.<TOKEN>_MANAGER
```

## Safe update procedure

1. Confirm the target file exists before editing it.
2. Read the existing declaration style and encoding; preserve its package, declaration form, ordering convention, indentation, and line endings.
3. Check for an exact existing `<TOKEN>_MANAGER` declaration. Do not add a duplicate.
4. If it is absent, add it as a sibling of the existing EventSource declarations, including the required comma/semicolon punctuation for the existing Java structure.
5. Re-read the file and verify that the generated Event reference and the shared declaration are identical.

Do not remove, rename, reorder, or otherwise reformat existing EventSource declarations. If the file is missing or its structure cannot be safely identified, stop and report the issue instead of guessing.
