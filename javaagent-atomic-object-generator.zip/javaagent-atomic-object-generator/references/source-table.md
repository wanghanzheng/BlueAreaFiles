# Atomic-object source table

Use a plain-text source table so an Agent does not need Excel parsing support. Markdown is recommended; UTF-8 CSV and a table pasted directly into the prompt are also supported.

## Required Markdown format

Name the file `<AtomicObject>.md` when possible. Include the atomic object name in the filename or state it explicitly in the prompt.

```markdown
原子对象名称：UdaAreaRange

| 参数名 | 参数类型 | 枚举类型（若参数为ENUM） | 枚举值 | 是否主键 |
|---|---|---|---|---|
| AreaGroupId | STRING | - | - | 是 |
| Mcc | STRING | - | - | 是 |
| Mnc | STRING | - | - | 是 |
| AreaType | ENUM | AreaType | TAI/GNB/NRCELL | 否 |
| TacStart | STRING | - | - | 是 |
| TacEnd | STRING | - | - | 否 |
| GnbIdStart | STRING | - | - | 是 |
| GnbIdEnd | STRING | - | - | 否 |
| NrCellIdStart | STRING | - | - | 是 |
| NrCellIdEnd | STRING | - | - | 否 |
```

## CSV alternative

Save as UTF-8 CSV with this exact header order:

```csv
参数名,参数类型,枚举类型（若参数为ENUM）,枚举值,是否主键
AreaGroupId,STRING,-,-,是
Mcc,STRING,-,-,是
AreaType,ENUM,AreaType,TAI/GNB/NRCELL,否
```

Keep one field per row and preserve row order. Use `-` or an empty cell for enum metadata on `STRING` rows. Keep enum values slash-separated in one cell. Use only `是` or `否` in the primary-key column.

## Validation

- Require all five columns for the standard source table. The `是否主键` column is especially required for Manager generation.
- Preserve the exact parameter spelling and row order.
- Require enum type and values on every `ENUM` row.
- Reject duplicate parameter names and unsupported parameter types instead of guessing.
- If the only available input is `.xlsx`, ask for a UTF-8 CSV, Markdown copy, or pasted table before generating code.
