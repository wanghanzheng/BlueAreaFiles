# Manager Java file

Use this reference when generating `<AtomicObject>Manager.java`.

## Output directory and package

Create the directory because it does not exist in a new atomic-object implementation:

```text
javaagent/csp-mml/src/main/java/com.huawei.uda.mml/<AtomicObject>Manager/
```

Write `<AtomicObject>Manager.java` inside that directory. Use:

```java
package com.huawei.uda.mml.internal.<AtomicObject>Manager;
```

The directory name and Java class name are both `<AtomicObject>Manager`.

## Primary-key source and validation

For Manager generation, require the source-table column `是否主键`.

- Treat rows whose value is `是` as primary-key fields.
- Preserve the table order; never infer primary keys from field names, the first field, or an existing Manager.
- Require at least one primary-key field. If the column is absent, contains an unsupported value, or marks no field as primary, stop and ask for correction.
- Use the same ordered primary-key list in both `getKeyFromEntity` and `getKeyFromConfig`.

## Key generation

Generate both methods as underscore-joined expressions over all primary-key fields:

```java
@Override
protected String getKeyFromEntity(<AtomicObject>Entity entity) {
    return entity.getPrimaryField1() + "_" + entity.getPrimaryField2();
}

@Override
protected String getKeyFromConfig(<AtomicObject> config) {
    return config.getPrimaryField1() + "_" + config.getPrimaryField2();
}
```

- Use Entity getters in `getKeyFromEntity` and command-model getters in `getKeyFromConfig`.
- For a `STRING` primary field, concatenate the getter result directly.
- For every non-`STRING` primary field, call `.toString()` before concatenation.
- Do not include non-primary fields or add a leading/trailing underscore.
- Primary fields are expected to be non-null; direct `.toString()` is intentional for non-String primary types.

## Fixed class structure

Use the generic base class and imports from the examples:

```java
public class <AtomicObject>Manager
        extends AbstractMMLObjectManager<<AtomicObject>Entity, <AtomicObject>, String> {
```

Generate the following fixed behavior, replacing the atomic-object name and the event token:

- Logger and private singleton instance.
- `getINSTANCE()` returns the singleton.
- `getConfigClass()` returns `<AtomicObject>.class`.
- `getEventPublisher()` returns `<AtomicObject>Manager.getINSTANCE()`, matching the existing examples.
- `publishAddEvent()` and `publishDeleteEvent()` publish asynchronously through `<AtomicObject>EventPublisher.getINSTANCE()` using `new <AtomicObject>Event(BaseEventType.<TOKEN>_UPDATE)`.
- `convertToEntity(<AtomicObject> config)` logs the config and returns `config.convertToEntity()`.
- `getLogPrefix()` returns `"<AtomicObject>Manager"`.

Derive `<TOKEN>` as uppercase snake case from the atomic-object name, for example `AcBindArea` → `AC_BIND_AREA` and `UdaAreaRange` → `UDA_AREA_RANGE`.

Use these imports as applicable:

```java
import com.huawei.uda.base.event.BaseEventType;
import com.huawei.uda.mml.cmdmodel.<AtomicObject>;
import com.huawei.uda.mml.entity.<AtomicObject>Entity;
import com.huawei.uda.mml.event.<AtomicObject>Event;
import com.huawei.uda.mml.internal.AbstractMMLObjectManager;
import com.huawei.uda.mml.publisher.<AtomicObject>EventPublisher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
```
