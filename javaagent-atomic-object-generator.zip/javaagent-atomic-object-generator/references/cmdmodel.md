# Command-model Java file

Use this reference when generating `javaagent/csp-mml/src/main/java/com.huawei.uda.mml/cmdmodel/<AtomicObject>.java` from the mandatory plain-text source table.

## Field mapping

Use the data rows of the source table in their original order.

- `STRING` maps to Java `String`.
- `ENUM` maps to `E<EnumType>Enum`. Examples: `AreaType` maps to `EAreaTypeEnum`; `EnableSwitch` maps to `EEnableSwitchEnum`.
- Preserve the parameter spelling and casing from column A, including the existing PascalCase-style field names such as `AtomCapName` and `AreaGroupId`.
- For every field, emit this annotation sequence and use the exact column-A name as the JSON property:

  ```java
  @Getter
  @Setter
  @JsonProperty(value = "FieldName")
  private JavaType FieldName;
  ```

- Keep field order identical in declarations, `toString`, `equals`, `hashCode`, and `convertToEntity` constructor arguments.

## Class and imports

Generate `public class <AtomicObject> implements MMLBASE` in package `com.huawei.uda.mml.cmdmodel`.

Use the imports required by the generated fields and these fixed dependencies:

```java
import com.fasterxml.jackson.annotation.JsonProperty;
import com.huawei.csp.om.cmsdk.configitembase.ConfigResult;
import com.huawei.csp.om.modeldef.annotation.ConfResource;
import com.huawei.csp.om.modeldef.annotation.Operation;
import com.huawei.csp.om.modeldef.annotation.OperationConst;
import com.huawei.uda.mml.entity.<AtomicObject>Entity;
import com.huawei.uda.mml.internal.<AtomicObject>Manager.<AtomicObject>Manager;
import lombok.Getter;
import lombok.Setter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Objects;
```

Also import each referenced enum from `com.huawei.uda.mml.enums`.

## Fixed class structure

Use the existing singleton and logger convention:

```java
private static final Logger LOGGER = LoggerFactory.getLogger(<AtomicObject>.class);

@Getter
public static <AtomicObject> instance = new <AtomicObject>();
```

The following methods are fixed. Replace only the atomic-object name, Entity/Manager names, and field-derived expressions.

- `ADD_<AtomicObject>()`: log entry, call `convertToEntity()`, then call `<AtomicObject>Manager.getINSTANCE().addOrUpdate(entity)`.
- `RMV_<AtomicObject>()`: create a `ConfigResult`, log entry, read the first field from the source table through its generated getter, call `removeEntity(firstField)`, and return the result.
- `MOD_<AtomicObject>(<AtomicObject> originData)`: log entry and origin data, return an empty `ConfigResult` when `originData == null`, otherwise convert and call `addOrUpdate`, then log success and return the result.
- `LST_<AtomicObject>()`: log entry only.
- `mmlOnline()`: log entry and call `<AtomicObject>Manager.getINSTANCE().initialize()`.
- `checkACSAndCacheValue(ArrayList<Object> dataList)`: guard null/empty input; accept only `<AtomicObject>` instances; convert each item; use the first source-table field as the cache lookup key; add missing entities or update unequal cached entities; skip equal entities.
- `convertToEntity()`: return `new <AtomicObject>Entity(...)` with every field in source-table order.

Use the fixed operation annotations and bilingual resources:

```java
@ConfResource({"新增", "ADD"})
@Operation(name = OperationConst.OPERA_ADD)
```

Use `{"删除", "Delete"}` for remove, `{"更新", "Modify"}` for modify, and `{"查询", "List"}` for list.

## Object methods

- Keep the existing concatenated-string style for `toString`, using the class name, braces, field names, values, and comma separators in source-table order. Do not replace it with `String.format` or a builder.
- Compare every field in `equals`; compare enum fields with `==` and object fields with `Objects.equals`.
- Include every field in `Objects.hash(...)` in source-table order.

## Enum source files required by this command model

`ENUM` fields are not assumed to have pre-existing enum classes. Generate the corresponding enum source under package `com.huawei.uda.mml.enums`, at exactly:

```text
javaagent/csp-mml/src/main/java/com.huawei.uda.mml/enums/
```

For each enum row:

- Name the enum `E<EnumType>Enum`.
- Use the slash-separated values from column D as enum constants, preserving order.
- Assign integer values starting at `0` in source order, matching `EEnableSwitchEnum` and `EAreaTypeEnum`.
- Include the `private final int value` field, constructor, `getValue()`, `fromValue(int)`, and `valueOf(int)` methods used by the examples.
- Make `fromValue` return the first enum constant when no value matches. Make `valueOf` throw `IllegalArgumentException("Invalid E<EnumType>Enum Value")` when no value matches.
- If multiple fields reference the same enum type, generate one enum file and reuse it.
