# Shared BaseEventType declaration

Every generated Event and Manager uses a BaseEventType constant. Update the shared declaration file after generating the Event and Manager files.

## Target file

Modify exactly:

```text
javaagent/service-base/src/main/java/com.huawei.uda.base/event/BaseEventType.java
```

## Declaration to add

Derive the uppercase snake-case token from the atomic-object name, then ensure this declaration exists:

```text
<TOKEN>_UPDATE
```

Examples:

- `AcBindArea` → `AC_BIND_AREA_UPDATE`
- `UdaAreaRange` → `UDA_AREA_RANGE_UPDATE`

This must match both generated references:

```java
BaseEventType.<TOKEN>_UPDATE
```

## Safe update procedure

1. Confirm the target file exists before editing it.
2. Read the existing declaration style and encoding; preserve its package, declaration form, ordering convention, indentation, and line endings.
3. Check for an exact existing `<TOKEN>_UPDATE` declaration. Do not add a duplicate.
4. If it is absent, add it as a sibling of the existing BaseEventType declarations, including the required comma/semicolon punctuation for the existing Java structure.
5. Re-read the file and verify that the generated Event/Manager references and the shared declaration are identical.

Do not remove, rename, reorder, or otherwise reformat existing BaseEventType declarations. If the file is missing or its structure cannot be safely identified, stop and report the issue instead of guessing.
