# Event Java file

Use this reference when generating `javaagent/csp-mml/src/main/java/com.huawei.uda.mml/event/<AtomicObject>Event.java`.

## Naming

Derive an uppercase snake-case token from the atomic object name:

- `AcBindArea` → `AC_BIND_AREA`
- `UdaAreaRange` → `UDA_AREA_RANGE`

Use this token for both framework constants:

- `EventSource.<TOKEN>_MANAGER`
- `BaseEventType.<TOKEN>_UPDATE`

## Fixed source template

Generate exactly this structure, replacing `<AtomicObject>` and `<TOKEN>`:

```java
package com.huawei.uda.mml.event;

import com.huawei.uda.base.event.BaseEvent;
import com.huawei.uda.base.event.BaseEventType;
import com.huawei.uda.base.event.EventSource;

public class <AtomicObject>Event extends BaseEvent {
    public <AtomicObject>Event(BaseEventType baseEventType) {
        super(baseEventType, EventSource.<TOKEN>_MANAGER);
    }
}
```

Write the file under the `event` directory. Do not add fields, event payloads, or other behavior.
