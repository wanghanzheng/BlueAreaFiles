# Entity Java file

Use this reference when generating `javaagent/csp-mml/src/main/java/com.huawei.uda.mml/entity/<AtomicObject>Entity.java`.

## Package, fields, and imports

Use package `com.huawei.uda.mml.entity` and class name `<AtomicObject>Entity`.

Generate one `private final` field for every source-table row, preserving the table order and the parameter spelling. Reuse the command-model type mapping:

- `STRING` → `String`.
- `ENUM` → `E<EnumType>Enum`, imported from `com.huawei.uda.mml.enums`.

Use `lombok.Getter` and `java.util.Objects`. Import only the enum types referenced by this entity.

## Fixed structure

Generate:

```java
@Getter
public class <AtomicObject>Entity {
    private final JavaType FieldName;

    public <AtomicObject>Entity(JavaType fieldName, ...) {
        this.FieldName = fieldName;
        // assign every field in source-table order
    }
}
```

The constructor must accept every field exactly once, in source-table order, and assign all final fields. Constructor parameter names may use lower camel case while field names retain the source-table spelling.

## Object methods

- Implement `toString()` with the existing `String.format` style: `"<AtomicObject> [Field1=%s, Field2=%s, ...]"`, listing every field in source-table order.
- Use the actual atomic-object name in the `toString` label; do not copy unrelated labels or known example typos.
- Implement `equals(Object o)` with the standard identity/null/class checks. Compare enum fields with `==` and all other fields with `Objects.equals`.
- Implement `hashCode()` with `Objects.hash(...)`, including every field in source-table order.
- Do not generate setters, mutable fields, extra business methods, or manager/event logic in this file.
