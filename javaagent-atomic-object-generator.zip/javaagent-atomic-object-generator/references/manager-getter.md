# ManagerGetter Java file

Use this reference when generating `<AtomicObject>ManagerGetter.java`.

## Required module name

The caller must provide the module name in the prompt. Do not infer it from the atomic object name, workbook name, or existing examples. If it is missing, ask the caller for the module name before creating the file.

## Output path and package

Write the file at:

```text
javaagent/csp-mml/src/main/java/com.huawei.uda.mml/api/<moduleName>/<AtomicObject>ManagerGetter.java
```

Use the matching package declaration:

```java
package com.huawei.uda.mml.api.<moduleName>;
```

Preserve the module name supplied by the caller in both the directory and package declaration.

## Fixed source template

Replace only `<AtomicObject>` and its derived Entity/Manager names:

```java
import com.huawei.uda.mml.entity.<AtomicObject>Entity;
import com.huawei.uda.mml.internal.<AtomicObject>Manager.<AtomicObject>Manager;

import java.util.List;

public class <AtomicObject>ManagerGetter {
    public static List<<AtomicObject>Entity> SelectAll() {
        return <AtomicObject>Manager.getINSTANCE().SelectAll();
    }
}
```

Do not add fields, constructors, CRUD methods, or extra behavior. The class name, generic return type, manager import, and `SelectAll()` call all derive directly from the atomic object name.
