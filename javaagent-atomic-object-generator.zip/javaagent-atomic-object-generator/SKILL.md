---
name: javaagent-atomic-object-generator
description: Generate the Java source files required by the javaagent project for a new atomic object from its mandatory Excel source table. Use when the user provides an atomic-object workbook such as AcBindArea.xlsx or UdaAreaRange.xlsx and asks to create or update files under javaagent/csp-mml/src/main/java/com.huawei.uda.mml.
---

# Javaagent atomic object generator

Generate javaagent atomic-object source files from the supplied `<AtomicObject>.xlsx` table. The workbook is a mandatory input and is the source of truth for field names, field order, Java types, enum types, and enum values.

## Required input and project root

- Locate the target `javaagent` project root before writing files.
- Require the matching `<AtomicObject>.xlsx` workbook. Do not invent fields or generate the object from a name alone.
- Read `Sheet1`. Expect columns A:D: `参数名`, `参数类型`, `枚举类型（若参数为ENUM）`, `枚举值`.
- When generating a Manager, also require column E `是否主键` and use its `是/否` values as the authoritative primary-key definition.
- Treat rows after the header as ordered field definitions. Ignore empty `Sheet2`/`Sheet3` sheets unless the workbook explicitly uses them later.
- Stop and report the exact missing information when the workbook is absent, the required columns are missing, or an `ENUM` row lacks its enum type or values.

## Generation workflow

1. Derive the atomic-object class name from the workbook filename, preserving its exact casing; verify it against any name supplied by the user.
2. Parse and validate the workbook before editing the project.
3. Read the relevant reference for the file category being generated. For the command model, read [references/cmdmodel.md](references/cmdmodel.md).
4. Resolve Java package paths from the project structure and preserve the existing javaagent package conventions.
5. Generate only the requested file categories, unless the user asks for all required files.
6. Re-read each generated file and verify imports, field order, class/method names, and output paths.

## Current supported category

- `cmdmodel/Xxx.java`, including the enum source files required by its `ENUM` fields. The command-model output path is `javaagent/csp-mml/src/main/java/com.huawei.uda.mml/cmdmodel`; enum output path is `javaagent/csp-mml/src/main/java/com.huawei.uda.mml/enums`.
- `api/<moduleName>/<AtomicObject>ManagerGetter.java`; read [references/manager-getter.md](references/manager-getter.md). The module name is mandatory prompt input; ask for it when it is not provided.
- `entity/<AtomicObject>Entity.java`; read [references/entity.md](references/entity.md). The output path is `javaagent/csp-mml/src/main/java/com.huawei.uda.mml/entity`.
- `event/<AtomicObject>Event.java`; read [references/event.md](references/event.md). The output path is `javaagent/csp-mml/src/main/java/com.huawei.uda.mml/event`.
- `publisher/<AtomicObject>EventPublisher.java`; read [references/publisher.md](references/publisher.md). The output path is `javaagent/csp-mml/src/main/java/com.huawei.uda.mml/publisher`.
- `<AtomicObject>Manager/<AtomicObject>Manager.java`; read [references/manager.md](references/manager.md). The output directory must be created at `javaagent/csp-mml/src/main/java/com.huawei.uda.mml/<AtomicObject>Manager`.

Additional categories will be added as their rules are confirmed from the AcBindArea and UdaAreaRange examples.
